# Fontes LaTeX do TCC

Arquivo principal: `tcc.tex`. Selecione XeLaTeX no editor ou no Overleaf.
O pacote preserva os textos do projeto e adapta somente os caminhos das três
imagens para que a pasta possa ser compilada independentemente do repositório.

Com Tectonic, execute nesta pasta:

```text
tectonic --keep-logs --keep-intermediates tcc.tex
```

Com uma distribuição TeX convencional, execute XeLaTeX, BibTeX e XeLaTeX
duas vezes, ou use `latexmk` com o arquivo de configuração incluído.
São necessários os pacotes abnTeX2 e os pacotes declarados em `fixos/pacotes.tex`.

A bibliografia usa `abntex2-alf-tcc.bst`, derivação identificada e com os avisos
de licença preservados. As letras dos anos são geradas automaticamente.
Não edite manualmente essas letras no campo de ano da bibliografia.

Os originais históricos de concepção permanecem no acervo externo identificado
no trabalho. A ficha catalográfica fornecida pelos autores está incluída como PDF
em pretextuais/. Os campos da data e dos membros convidados da banca ficam em branco.
O relatório CopySpider recebido foi analisado antes desta substituição da ficha
e dos campos da banca; o conteúdo do restante do trabalho permanece preservado.
A confirmação sobre a seção 3.3.1
e o Apêndice L foi informada por Julio; não equivale à aprovação da defesa.
